<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12">
			
				<?php 
					include"body/navbar.php";
				 ?>
				 

			</div><!-- penutup navbar -->

			<div class="col-md-12" style="margin-top:-10px;">
				
				<?php 
					include"body/slide.php";
				 ?>

				 <div style="margin-top: 10px;" class="panel panel-default">
				  <div class="panel-body">
				    PARTISIPASI DAN KERJA SAMA DARI SAUDARA SANGAT DIHARAPKAN GUNA PERBAIKAN DAN PENINGKATAN MUTU AKADEMIK STMIK NURDIN HAMZAH
				  </div>
				</div>
				


			</div><!-- penutup slide -->

			<div class="col-md-8">
			  	<div class="panel panel-primary">
				  <div class="panel-heading">PETUNJUK PENGISIAN <span style="float: right;" class="glyphicon glyphicon-envelope"></span></div>
				  <div class="panel-body">
				    *Berikan respon anda untuk setiap indikator  yang ada pada Form yang nantinya akan anda pilih <br><br>
				    <p>*Angka 1‐6 pada kolom Penilaian jawaban menggambarkan  tingkat kesesuaian setiap situasi/keadaan  dengan harapan anda. Semakin tinggi angka yang anda pilih (angka 6) artinya kondisi/situasi  pada pernyataan betul‐ betul  sesuai   dengan   harapan   anda  sedangkan   semakin   kecil  angka  yang  anda  pilih  (angka  1),  maka kondisi/situasi pada pernyataan sangat tidak sesuai dengan harapan anda.</p>

				    <br>
				    <p>PENTING : Kuesioner ini digunakan untuk mengukur dan mengetahui tingkat kepuasan mahasiswa/i UNIGHA  terhadap pelayanan akademik dan non-akademik di lingkungan Universitas Jabal Ghafur.</p>
				  </div>
				</div>
			 </div>
		    <div class="col-md-4">
		  		<div class="panel panel-default">
					  <div class="panel-body">
						    DATA AKUN PENDAFTAR
						  </div>

						  <div class="panel panel-default">
						  <div class="panel-body">
						  			 <table class="table table-striped">

						  	<?php

								include"koneksi.php";

								$no = 0;
										$sql = "select * from account order by id_account desc";
										$query = mysqli_query($login,$sql);
										while ($data = mysqli_fetch_assoc($query))
										{
									$no++;
						  ?>		 
									  <tr>
									  	<td><?php echo $data['nama']?></td>
									  </tr>
									  <?php

										}

						   ?>
									</table>

						  </div>
						</div>
					</div>	
		    </div><!-- penutup ptunjuk-->

					
			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>