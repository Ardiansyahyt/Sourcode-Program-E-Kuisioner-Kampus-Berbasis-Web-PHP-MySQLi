<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12">
			
				<?php 
					include"body/navbar.php";
				 ?>

			</div><!-- penutup navbar -->

			<div class="col-md-12" style="margin-top:-20px;">
				
				<?php 
					include"body/slide.php";
				 ?>

				 <div class="row">
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/2.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				</div>

				<div class="row">
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/2.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/2.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				</div>

				<div class="row">
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/2.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/2.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-3">
				    <a href="#" class="thumbnail">
				      <img src="img/1.jpg" alt="..." id="tinggi1">
				    </a>
				  </div>
				</div>

			</div><!-- penutup slide -->

			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>