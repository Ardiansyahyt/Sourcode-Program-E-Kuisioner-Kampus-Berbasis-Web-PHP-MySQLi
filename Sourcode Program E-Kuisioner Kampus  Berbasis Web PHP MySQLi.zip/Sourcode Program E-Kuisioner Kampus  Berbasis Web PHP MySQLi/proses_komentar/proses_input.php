  <?php

  include"../koneksi.php";

  if ( isset($_POST['simpan']) )
  {
	  $nama = $_POST['komentar'];
	  $tgl = date("d-F-Y");
	  $jam=date("H:i:s");
	  
	  

	  $sql = "insert into komentar (komentar,tanggal,jam)
			VALUES ('$nama','$tgl','$jam')";
	 
	  if(empty($nama))
			{

				echo"<script type='text/javascript'>
								   //<![CDATA[
										alert('Data tidak boleh kosong');
										window.location='../index.php';				   
								   //]]>
								 </script>"; 

			}elseif(  mysql_query($sql) )
			{
				
				echo"<script type='text/javascript'>
									   //<![CDATA[
											alert('Komentar telah terkirim');
											window.location='../forum.php';				   
									   //]]>
									 </script>"; 
			}
			else
			{
				echo"<script type='text/javascript'>
								   //<![CDATA[
										alert('Gagal');
										window.location='../diskusi.php';				   
								   //]]>
								 </script>"; 
			}	
				
		
		
		}

?>