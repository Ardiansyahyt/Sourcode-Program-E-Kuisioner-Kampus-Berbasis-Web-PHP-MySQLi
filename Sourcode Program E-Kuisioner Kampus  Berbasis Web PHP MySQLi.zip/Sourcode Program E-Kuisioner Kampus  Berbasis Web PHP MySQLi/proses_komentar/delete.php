<?php
		include"../koneksi.php";

		$id = $_GET['hapus'];
		$sql1 = "delete from komentar where id_komentar='$id'";

		if ( mysql_query($sql1))

		{
		
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Data sudah di hapus');
									window.location='../komen.php';				   
							   //]]>
							 </script>"; 
		}
		else
		{
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Gagal');
									window.location='../$area';				   
							   //]]>
							 </script>"; 
		}
		

?>