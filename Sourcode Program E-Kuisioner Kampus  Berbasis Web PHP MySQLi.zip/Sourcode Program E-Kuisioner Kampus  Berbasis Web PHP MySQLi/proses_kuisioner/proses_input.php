 <?php

	include"../koneksi.php";
	
	if ( isset($_POST['proses']) )
	{
		$nama =	$_POST['nama'];
		$jurusan = $_POST['jurusan'];
		$prodi = $_POST['prodi'];
		$nilai1 = $_POST['nilai1'];
		$nilai2 = $_POST['nilai2'];
		$nilai3 = $_POST['nilai3'];
		$nilai4 = $_POST['nilai4'];
		$nilai5 = $_POST['nilai5'];
		$nilai6 = $_POST['nilai6'];
		$nilai7 = $_POST['nilai7'];
		$nilai8 = $_POST['nilai8'];
		$nilai9 = $_POST['nilai9'];
		$nilai10 = $_POST['nilai10'];
		$nilai11 = $_POST['nilai11'];
		$nilai12 = $_POST['nilai12'];
		$nilai13 = $_POST['nilai13'];
		$nilai14 = $_POST['nilai14'];
		
		
		$sql = "INSERT INTO `tbl_kuisioner` (`id_kuisioner`, `nama`, `jurusan`, `prodi`, `nilai1`, `nilai2`, `nilai3`, `nilai4`, `nilai5`, `nilai6`, `nilai7`, `nilai8`, `nilai9`, `nilai10`, `niali11`, `nilai12`, `nilai13`, `nilai14`) VALUES (NULL, '$nama', '$jurusan', '$prodi', '$nilai1', '$nilai2', '$nilai3', '$nilai4', '$nilai5', '$nilai6', '$nilai7', '$nilai8', '$nilai9', '$nilai10', '$nilai11', '$nilai12', '$nilai13', '$nilai14')";

		if( mysqli_query($login,$sql) )
		{
			
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Data Berhasil Disimpan');
									window.location='../form_kuisioner.php';				   
							   //]]>
							 </script>"; 
		}
		else
		{
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Gagal');
									window.location='../form_kuisioner.php';				   
							   //]]>
							 </script>"; 
		}	
				
		
		
	}

?>
