<?php
		include"../koneksi.php";

		$id = $_GET['hapus'];
		$sql1 = "delete from tbl_kuisioner where id_kuisioner='$id'";

		if ( mysqli_query($login,$sql1))

		{
		
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Data sudah di hapus');
									window.location='../data_kuisioner.php';				   
							   //]]>
							 </script>"; 
		}
		else
		{
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Gagal');
									window.location='../data_kuisioner.php';				   
							   //]]>
							 </script>"; 
		}
?>