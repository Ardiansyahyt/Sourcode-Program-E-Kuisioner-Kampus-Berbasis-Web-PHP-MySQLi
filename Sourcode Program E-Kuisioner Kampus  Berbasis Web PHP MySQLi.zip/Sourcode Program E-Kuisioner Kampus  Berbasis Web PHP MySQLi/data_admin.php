<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			

			<div class="col-md-12" style="margin-top:20px;">
				
				
				<div class="col-md-12">
					<div class="panel panel-default">
					  <div class="panel-body">
					    AKUN ADMIN <br><br>
					    <a href="master.php" class="btn btn-primary">BACK</a>
					  </div>

					  <div class="panel panel-default">
					  <div class="panel-body">
					  			 <table class="table table-striped">

					  	<?php

							include"koneksi.php";

							$no = 0;
									$sql = "select * from admin order by id_admin desc";
									$query = mysqli_query($login,$sql);
									while ($data = mysqli_fetch_assoc($query))
									{
								$no++;
					  ?>		 
								  <tr>
								  	<td><?php echo $data['username']?></td>
								  	<td><?php echo $data['password']?></td>
								  </tr>
								  <?php

									}

					   ?>
								</table>

					  </div>
					</div>
				</div>	
				</div>

				

			

	</div><!-- penutup backround -->



</div>
</body>
</html>