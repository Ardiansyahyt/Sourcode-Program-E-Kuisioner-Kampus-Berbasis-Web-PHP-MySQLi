<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			

			<div class="col-md-12" style="margin-top:20px;">
				
				
				<div class="col-md-12">
					<div class="panel panel-default">
					  <div class="panel-body">
					    DATA AKUN PENDAFTAR <br><br>
					    <a href="master.php" class="btn btn-primary">BACK</a>
					  </div>

					  <div class="panel panel-default">
					  <div class="panel-body">
					  			 <table class="table table-striped">

					  	<?php

							include"koneksi.php";

							$no = 0;
									$sql = "select * from account order by id_account desc";
									$query = mysqli_query($login,$sql);
									while ($data = mysqli_fetch_assoc($query))
									{
								$no++;
					  ?>		 
								  <tr>
								  	<td><?php echo $data['nama']?></td>
								  	<td><?php echo $data['password']?></td>
								  	<td><a href="editakun.php?id=<?php echo $data['id_account'];?>" title="Edit">Edit</a>||<a href="proses_account/proses_delete.php?hapus=<?php echo $data['id_account']?>">Hapus</a></td>
								  </tr>
								  <?php

									}

					   ?>
								</table>

					  </div>
					</div>
				</div>	
				</div>

				

			

	</div><!-- penutup backround -->



</div>
</body>
</html>