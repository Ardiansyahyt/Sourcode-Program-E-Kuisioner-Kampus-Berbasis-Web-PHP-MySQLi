<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<font face="elephant" size="15pt" color="white"><b><center>SELAMAT DATANG DI WEBSITE RESMI KUISIONER STMIK NURDIN HAMZAH</center></b></font>
			</div>
		</div>
		<div class="row" style="margin-top: 100px;">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-4">
						<font face="elephant" color="white" size="5pt"><center>LOGIN AKUN</center></font>
						<form role="form" method="post" action="#">
						  <div class="form-group">
						    <label for="exampleInputEmail1" style="color: white;">Username</label>
						    <input type="text" name="nama" class="form-control" id="exampleInputEmail1" placeholder="Enter Username" required>
						  </div>
						  <div class="form-group">
						    <label for="exampleInputPassword1"  style="color: white;">Password</label>
						    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
						  </div>	
						  <font color="white">Belum Punya akun ??? Daftar dahulu ??????</font>					  
						  <a class="btn btn-danger" href="account.php">Daftar</a>
						  <center><button class="btn btn-info" name="proses">LOGIN</button></center>
						</form>
						<?php


									if (isset($_POST['proses']))
									{

										include ('koneksi.php');

										$user=$_POST['nama'];
										$pass=$_POST['password'];

										$masuk="select count(nama) from account where nama='$user' and password='$pass'";
										$query=mysqli_query($login,$masuk);
										$chek=mysqli_fetch_row($query);
										

													
										if ( $chek[0]>0 )
										{
											echo"<script type='text/javascript'>
											   //<![CDATA[
													alert('selamat datang $user');
													window.location='kuisioner.php';				   
											   //]]>
											 </script>"; 

										}else
										{
											echo"<script type='text/javascript'>
											   //<![CDATA[
													alert('gagal $user');
													window.location='index.php';				   
											   //]]>
											 </script>"; 
										}
									}	

								
							 
							?>
					</div>
					<div class="col-md-4"></div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>