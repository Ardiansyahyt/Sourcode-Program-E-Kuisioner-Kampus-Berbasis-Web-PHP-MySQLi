<?php

	$login=mysqli_connect("localhost","root","","kuisioner");

?>