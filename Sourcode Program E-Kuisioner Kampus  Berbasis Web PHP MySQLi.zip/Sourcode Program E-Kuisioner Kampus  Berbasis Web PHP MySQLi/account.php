<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:170px;">
				
				<div class="col-md-4">
					
				</div>
				<div class="col-md-4" style="background:purple;">
					<div class="panel panel-default">
					  <div class="panel-body">
						DAFTAR ACCOUNT UNTUK MENGISI KUISIONER <span class="glyphicon glyphicon-ok"></span>
					  </div>
					</div>
					<div class="panel panel-default">
					  <div class="panel-body">
					    <form role="form" method="post" action="proses_account/proses_daftar.php">
						  <div class="form-group">
						    <label for="exampleInputEmail1">USERNAME</label>
						    <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter username" required>
						  </div>
						  <div class="form-group">
						    <label for="exampleInputPassword1">PASSWORD</label>
						    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
						  </div>
						 <a class="btn btn-danger" href="index.php">BACK</a>
						  <button type="submit" name="proses" class="btn btn-primary" style="margin-left:220px;margin-top: -56px;">SIMPAN</button>
						</form>
					  </div>
					</div>
				</div>
				<div class="col-md-4">
					
				</div>

		</div><!-- penutup slide -->
			
	</div><!-- penutup backround -->



</div>
</body>
</html>