<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12">
			
				<?php 
					include"body/navbar.php";
				 ?>

			</div><!-- penutup navbar -->

			<div class="col-md-12" style="margin-top:-20px;">
				
				
				<div class="col-md-12">
					<div class="panel panel-default">
					  <div class="panel-body">
					    FORUM EDIT BERITA ANIME
					  </div>

					  <div class="panel panel-default">
					  <div class="panel-body">
			  			 
			  			 <form method="post" action="proses_berita/proses_update_berita.php" enctype="multipart/form-data">
			  			 	<table class="table table-striped">
			  			 	<?php

								include"koneksi.php";
								
								$id =$_GET['id'];
								$sql = "select * from berita where id_berita ='$id'";
								$query= mysql_query ($sql);
								$show = mysql_fetch_assoc ($query);

							?>	

				  			 <tr>
				  			 	<input type="hidden" name="id" value="<?php echo $show['id_berita'];?>" />
				  			 	<td>Judul</td>
				  			 	<td>:</td>
				  			 	<td><input type="text" name="judul" value="<?php echo $show['judul']?>" /></td>

				  			 </tr>
				  			 <tr>
				  			 	<td>Penulis</td>
				  			 	<td>:</td>
				  			 	<td><input type="text" name="penulis" value="<?php echo $show['penulis']?>" /></td>
				  			 </tr>
				  			 <tr>
				  			 	<td>Tanggal</td>
				  			 	<td>:</td>
				  			 	<td><input type="text" name="tanggal" value="<?php echo $show['tanggal']?>" /></td>
				  			 </tr>
				  			 <tr>
				  			 	<td>Jam</td>
				  			 	<td>:</td>
				  			 	<td><input type="text" name="jam" value="<?php echo $show['jam']?>" /></td>
				  			 </tr>
				  			 <tr>
				  			 	<td>foto</td>
				  			 	<td>:</td>
				  			 	<td><input type="file" name="foto" accept="image/*" value="img_berita/<?php echo $show['foto']?>" /></td>
				  			 </tr>
				  			 <tr>
				  			 	<td>Isi</td>
				  			 	<td>:</td>
				  			 	<td>
				  			 		<textarea cols="22" rows="5" name="isi" value="">
				  			 			<?php echo $show['isi']?>
				  			 		</textarea>
				  			 	</td>
				  			 </tr>
				  			 <tr>
				  			 	<td><input type="reset" value="CANCEL" /></td>
				  			 	<td><input type="submit" name="update" value="UPDATE" /></td>
				  			 	<td><a href="data_berita.php">LIHAT DATA</a></td>

				  			 </tr>
			  	
						</table>

			  			 </form>

					  </div>
					</div>
				</div>	
				</div>

				

			</div><!-- penutup slide -->

			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>