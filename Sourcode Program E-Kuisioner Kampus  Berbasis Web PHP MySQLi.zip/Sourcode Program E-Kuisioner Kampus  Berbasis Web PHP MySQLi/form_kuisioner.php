<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12">
			
				<?php 
					include"body/navbar.php";
				 ?>
				 

			</div><!-- penutup navbar -->

			<div class="col-md-12" style="margin-top:-10px;">
				
				<?php 
					include"body/slide.php";
				 ?>

				 <div style="margin-top: 10px;" class="panel panel-default">
				  <div class="panel-body">
				    PARTISIPASI DAN KERJA SAMA DARI SAUDARA SANGAT DIHARAPKAN GUNA PERBAIKAN DAN PENINGKATAN MUTU AKADEMIK STMIK NURDIN HAMZAH
				  </div>
				</div>
				


			</div><!-- penutup slide -->

			<div class="col-md-8">
			  	<div class="panel panel-primary">
				  <div class="panel-heading">FORM PENGISIAN <span style="float: right;" class="glyphicon glyphicon-envelope"></span></div>
				  <div class="panel-body">
				    <form role="form" method="post" action="proses_kuisioner/proses_input.php">
				      <p style="color: black;"><b><center>Biodata Mahasiswa</center></b></p> 	
					  <div class="form-group">
					    <label for="exampleInputEmail1" style="color: black;">Nama :</label>
					    <input type="text" name="nama" class="form-control" id="exampleInputEmail1" placeholder="Enter Username">
					  </div>
					  
					  <div class="form-group">
					  	<label style="color: black;">Jurusan :</label>
					  	<input type="text" name="jurusan" class="form-control" placeholder="Jurusan" required>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">PRODI :</label>
					  	<select name="prodi" class="form-control">
					  		<option>--Pilih--</option>
					  		<option value="Teknik Informatika">Teknik Informatika</option>
					  		<option value="Sistem Informasi">Sistem Informasi</option>
					  	</select>
					  </div>
					  <p style="color: black;"><b><center>Fasilitas : Jawablah berapa nilainya dari range 1-6</center></b></p>

					  <div class="form-group">
					  	<label style="color: black;">Laboratorium computer :</label>
					  	<select name="nilai1" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Kecanggihan/keterbaruan laboratorium komputer :</label>
					  	<select name="nilai2" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">RUANGAN :</label>
					  	<select name="nilai3" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Fasilitas pendingin/penyejuk  ruangan :</label>
					  	<select name="nilai4" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Ruang perpustakaan :</label>
					  	<select name="nilai5" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Koleksi perpustakaan :</label>
					  	<select name="nilai6" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Fasilitas  Wifi Gratis/Hot Spot :</label>
					  	<select name="nilai7" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Taman/ Hall/ Ruang public :</label>
					  	<select name="nilai8" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Area parker :</label>
					  	<select name="nilai9" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Kantin :</label>
					  	<select name="nilai10" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Fasilitas Olah raga :</label>
					  	<select name="nilai11" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Fasilitas Ekstra kurikuler :</label>
					  	<select name="nilai12" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Fasilitas Ibadah :</label>
					  	<select name="nilai13" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <div class="form-group">
					  	<label style="color: black;">Kamar mandi/Toilet :</label>
					  	<select name="nilai14" class="form-control">
					  		<option>--Pilih Nilai--</option>
					  		<option value="1">1</option>
					  		<option value="2">2</option>
					  		<option value="3">3</option>
					  		<option value="4">4</option>
					  		<option value="5">5</option>
					  		<option value="6">6</option>
					  	</select>
					  </div>

					  <input type="reset" class="btn btn-primary" name="CANCEL" value="CANCEL">
					  <input style="float: right;" type="submit" class="btn btn-danger" name="proses" value="SIMPAN">
					  <p style="color: black;"><b><center>Terima kasih atas waktu dan kerjasama anda.</center></b></p>
					</form>
				  </div>
				</div>
			 </div>
		    <div class="col-md-4">
		  		<div class="panel panel-primary">
					  <div class="panel-body">
						    DATA AKUN PENDAFTAR
						  </div>

						  <div class="panel panel-primary">
						  <div class="panel-body">
						  			 <table class="table table-striped">

						  	<?php

								include"koneksi.php";

								$no = 0;
										$sql = "select * from account order by id_account desc";
										$query = mysqli_query($login,$sql);
										while ($data = mysqli_fetch_assoc($query))
										{
									$no++;
						  ?>		 
									  <tr>
									  	<td><?php echo $data['nama']?></td>
									  </tr>
									  <?php

										}

						   ?>
									</table>

						  </div>
						</div>
					</div>	
		    </div><!-- penutup ptunjuk-->

					
			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>