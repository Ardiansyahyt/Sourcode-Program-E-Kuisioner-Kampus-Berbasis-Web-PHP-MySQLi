<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12">
			
				<?php 
					include"body/navbar.php";
				 ?>

			</div><!-- penutup navbar -->

			<div class="col-md-12" style="margin-top:-20px">
				
				<div class="col-md-4">
					
				</div>
				<div class="col-md-4" style="background:#C3C3E3;">
					<div class="panel panel-default">
					  <div class="panel-body">
					    LOGIN UNTUK MULAI BERDISKUSI <span class="glyphicon glyphicon-ok"></span>
					  </div>
					</div>
					<div class="panel panel-default">
					  <div class="panel-body">
					    <form role="form" method="post" action="#">
						  <div class="form-group">
						    <label for="exampleInputEmail1">USERNAME</label>
						    <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter username">
						  </div>
						  <div class="form-group">
						    <label for="exampleInputPassword1">PASSWORD</label>
						    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
						  </div>
						  <button type="submit" name="login" class="btn btn-primary"  style="margin-left:227px;">LOGIN</button>
						</form>

						<?php 

						if (isset($_POST['login'])){

							include ('koneksi.php');
							$user=$_POST['username'];
							$pass=$_POST['password'];

							$masuk="select count(nama) from account where nama='$user' and password='$pass'";
							$query=mysql_query($masuk);
							$chek=mysql_fetch_row($query);

							if ( $chek[0]>0 )
							{
								echo"<script type='text/javascript'>
								   //<![CDATA[
										alert('selamat datang $user');
										window.location='forum.php';				   
								   //]]>
								 </script>"; 

							}else
							{
								echo"<script type='text/javascript'>
								   //<![CDATA[
										alert('gagal $user');
										window.location='index.php';				   
								   //]]>
								 </script>"; 
							}
						}	

						 ?>

					  </div>
					</div>
				</div>
				<div class="col-md-4">
					
				</div>

			</div><!-- penutup slide -->

			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>