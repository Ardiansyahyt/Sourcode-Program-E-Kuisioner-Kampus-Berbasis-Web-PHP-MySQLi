<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<font face="elephant" size="15pt" color="white"><b><center>SELAMAT DATANG ADMIN<p>KUISIONER</p>	</center></b></font>
		</div>

			

			<div class="col-md-12" style="margin-top:50px">
				
				<div class="col-md-4">
					
				</div>
				<div class="col-md-4" style="background:purple;">
					<div class="panel panel-default">
					  <div class="panel-body">
					    LOGIN ADMIN <span class="glyphicon glyphicon-ok"></span>
					  </div>
					</div>
					<div class="panel panel-default">
					  <div class="panel-body">
					    <form role="form" method="post" action="#">
						  <div class="form-group">
						    <label for="exampleInputEmail1">USERNAME</label>
						    <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter username">
						  </div>
						  <div class="form-group">
						    <label for="exampleInputPassword1">PASSWORD</label>
						    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
						  </div>
						  <button type="submit" name="proses" class="btn btn-primary"  style="margin-left:227px;">LOGIN</button>
						</form>

							<?php


									if (isset($_POST['proses']))
									{

										include ('koneksi.php');

										$user=$_POST['username'];
										$pass=$_POST['password'];

										$masuk="select count(username) from admin where username='$user' and password='$pass'";
										$query=mysqli_query($login,$masuk);
										$chek=mysqli_fetch_row($query);
										

													
										if ( $chek[0]>0 )
										{
											echo"<script type='text/javascript'>
											   //<![CDATA[
													alert('selamat datang $user');
													window.location='master.php';				   
											   //]]>
											 </script>"; 

										}else
										{
											echo"<script type='text/javascript'>
											   //<![CDATA[
													alert('gagal $user');
													window.location='admin.php';				   
											   //]]>
											 </script>"; 
										}
									}	

								
							 
							?>


					  </div>
					</div>
				</div>
				<div class="col-md-4">
					
				</div>

			</div><!-- penutup slide -->

			

	</div><!-- penutup backround -->



</div>
</body>
</html>