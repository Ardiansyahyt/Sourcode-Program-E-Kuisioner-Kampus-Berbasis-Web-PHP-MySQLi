<?php
		include"../koneksi.php";

		$id = $_GET['hapus'];
		$sql1 = "delete from account where id_account='$id'";

		if ( mysqli_query($login,$sql1))

		{
		
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Data sudah di hapus');
									window.location='../dataakun.php';				   
							   //]]>
							 </script>"; 
		}
		else
		{
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Gagal');
									window.location='../dataakun.php';				   
							   //]]>
							 </script>"; 
		}
?>