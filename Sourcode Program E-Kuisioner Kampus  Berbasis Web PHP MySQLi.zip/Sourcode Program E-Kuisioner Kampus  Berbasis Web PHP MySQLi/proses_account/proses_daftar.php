<?php


		if (isset($_POST['proses']))
		{

			include ('../koneksi.php');

			$user=$_POST['username'];
			$pass=$_POST['password'];

			$simpan = "INSERT INTO account (nama,password)
									     VALUES('$user','$pass')";
			

			
			if(  mysqli_query($login,$simpan) )
			{
				
				echo"<script type='text/javascript'>
									   //<![CDATA[
											alert('Register Telah selesai');
											window.location='../index.php';				   
									   //]]>
									 </script>"; 
			}
			else
			{
				echo"<script type='text/javascript'>
								   //<![CDATA[
										alert('Gagal');
										window.location='../index.php';				   
								   //]]>
								 </script>"; 
			}	
				
		
		
		}
	
 
?>
