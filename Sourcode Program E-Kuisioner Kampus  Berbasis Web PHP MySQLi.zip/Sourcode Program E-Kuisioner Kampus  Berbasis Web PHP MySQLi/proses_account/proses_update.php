<?php

	include"../koneksi.php";

	if ( isset($_POST['update']) )
	{
	  $id =  $_POST['id'];
	  $nm = $_POST['username'];
	  $psw = $_POST['password'];

	  $edit  = "update account set  nama = '$nm',
									     password = '$psw' where id_account = '$id'";

	  if(  mysqli_query($login,$edit))
			{
				
				echo"<script type='text/javascript'>
									   //<![CDATA[
											alert('Data telah Update');
											window.location='../dataakun.php';				   
									   //]]>
									 </script>"; 
			}
			else
			{
				echo"<script type='text/javascript'>
								   //<![CDATA[
										alert('Gagal di Update');
										window.location='../index.php';				   
								   //]]>
								 </script>"; 
			}	
	}

?>