<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			

			<div class="col-md-12" style="margin-top:20px;">
				<a href="index.php" class="btn btn-info">LOG OUT</a>
				<div class="row">
				  <div class="col-xs-6 col-md-4">
				    <a href="data_admin.php" class="thumbnail" style="text-align:center;">
				      ADMIN <span class="glyphicon glyphicon-th-list" id="tinggi"></span>
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-4">
				    <a href="data_kuisioner.php" class="thumbnail" style="text-align:center;">
				      DATA KUISIONER <span class="glyphicon glyphicon-th" id="tinggi"></span>
				    </a>
				  </div>
				  <div class="col-xs-6 col-md-4">
				    <a href="dataakun.php" class="thumbnail" style="text-align:center;">
				      ACCOUNT <span class="glyphicon glyphicon-user" id="tinggi"></span>
				    </a>
				  </div>
				</div>

			</div><!-- penutup slide -->

			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>