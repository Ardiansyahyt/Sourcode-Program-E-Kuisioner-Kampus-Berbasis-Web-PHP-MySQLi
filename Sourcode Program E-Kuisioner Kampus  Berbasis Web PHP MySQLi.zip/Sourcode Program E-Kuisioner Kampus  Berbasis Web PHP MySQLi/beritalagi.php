<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12">
			
				<?php 
					include"body/navbar.php";
				 ?>

			</div><!-- penutup navbar -->

			<div class="col-md-12" style="margin-top:-20px;">
				
				<div class="row">
					<div class="col-md-3">
						<ul class="list-group">
						  <li class="list-group-item">ANIME JAMBI</li>
						  <li class="list-group-item">ANIME JAKARTA</li>
						  <li class="list-group-item">ANIME JEPANG</li>
						  <li class="list-group-item">ANIME KOREA</li>
						  <li class="list-group-item">ANIME MEDAN</li>
						</ul>
					</div>
					<div class="col-md-6" style="background:#fff;">
						<div class="row">
							<?php

				                include"koneksi.php";                
				                $no =0;
				                  	
				                  	$id =$_GET['id'];
				                    $sql = "SELECT * FROM berita WHERE id_berita='$id'";
				                    $query = mysql_query($sql);
				                    
				                    while ( $data = mysql_fetch_array($query))
				                    
				                    {

				                  $no++;
				                ?>
								<div class="col-md-12">
									<img src="img_berita/<?php echo $data['foto']?>" width="100%" height="100" alt="005" />
								</div>
								
								<div class="col-md-12">
									<p><?php echo $data['judul']?></p>
									 <p><?php echo $data['penulis']?>| <?php echo $data['tanggal']?> | <?php echo $data['jam']?></p><hr/>
									 <p><?php echo $data['isi']?></p>
									 
									 
								</div>
								<?php } ?>
																																					
						</div>
					</div>
					<div class="col-md-3">
						<ul class="list-group">
						  <li class="list-group-item">FORUM ANIME JAMBI</li>
						  <li class="list-group-item">FORUM ANIME JAKARTA</li>
						  <li class="list-group-item">FORUM ANIME JEPANG</li>
						  <li class="list-group-item">FORUM ANIME KOREA</li>
						  <li class="list-group-item">FORUM ANIME MEDAN</li>
						</ul>
					</div>
				</div><br/>
			
				<div class="row">
					<div class="col-md-12" style="margin-top:-20px;">
				
				<div class="row">
					<div class="col-md-3">
						<ul class="list-group">
						  <li class="list-group-item">ANIME JAMBI</li>
						  <li class="list-group-item">ANIME JAKARTA</li>
						  <li class="list-group-item">ANIME JEPANG</li>
						  <li class="list-group-item">ANIME KOREA</li>
						  <li class="list-group-item">ANIME MEDAN</li>
						</ul>
					</div>
					<div class="col-md-6" style="background:#fff;">
								<div class="panel panel-default">
								  <div class="panel-body">
									    FORUM ANIME
									  </div>

									  <div class="panel panel-default">
									  <div class="panel-body">
									    <form role="form" method="post" action="proses_komentar/proses_input.php">
										  <div class="form-group">
										    <textarea rows="6" cols="66" name="komentar">
										    	
										    </textarea>
										  </div>
										  <button type="submit" name="simpan" class="btn btn-warning"  style="margin-left:398px;">KOMENTAR</button>
										</form>
										<?php

											include"koneksi.php";

											$no = 0;
													$sql = "select * from komentar order by id_komentar desc";
													$query = mysql_query($sql);
													while ($data = mysql_fetch_assoc($query))
													{
												$no++;
									  ?>
												 <h5><?php echo $data['komentar']?></h5>
												 <h6><?php echo $data['tanggal']?></h6>
												 <h6><?php echo $data['jam']?></h6>
												  <hr/>
									  <?php

													}

									   ?>

								  </div>
								</div>
							</div>
					</div>
					<div class="col-md-3">
						<ul class="list-group">
						  <li class="list-group-item">FORUM ANIME JAMBI</li>
						  <li class="list-group-item">FORUM ANIME JAKARTA</li>
						  <li class="list-group-item">FORUM ANIME JEPANG</li>
						  <li class="list-group-item">FORUM ANIME KOREA</li>
						  <li class="list-group-item">FORUM ANIME MEDAN</li>
						</ul>
					</div>
				</div>
				
			</div><!-- penutup slide -->
				</div>	
			</div><!-- penutup slide -->


			<div class="col-md-12">
				
				<?php 
					include"body/footer.php";
				 ?>

			</div><!-- penutup footer -->

	</div><!-- penutup backround -->



</div>
</body>
</html>