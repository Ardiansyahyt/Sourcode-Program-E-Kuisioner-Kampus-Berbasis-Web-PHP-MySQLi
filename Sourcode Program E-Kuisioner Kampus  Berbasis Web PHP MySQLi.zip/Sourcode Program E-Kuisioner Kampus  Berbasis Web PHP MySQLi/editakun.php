<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			<div class="col-md-12" style="margin-top:20px">
				
				<div class="col-md-4">
					
				</div>
				<div class="col-md-4" style="background:#C3C3E3;">
					<div class="panel panel-default">
					  <div class="panel-body">
						DAFTAR ACCOUNT UNTUK MULAI BERDISKUSI <span class="glyphicon glyphicon-ok"></span>
					  </div>
					</div>
					<div class="panel panel-default">
					  <div class="panel-body">

					  	<?php

							include"koneksi.php";
							
							$id =$_GET['id'];
							$sql = "select * from account where id_account ='$id'";
							$query= mysqli_query ($login,$sql);
							$show = mysqli_fetch_assoc ($query);

						?>	

					    <form role="form" method="post" action="proses_account/proses_update.php">
					      <input type="hidden" name="id" value="<?php echo $show['id_account'];?>" />
						  <div class="form-group">
						    <label for="exampleInputEmail1">USERNAME</label>
						    <input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Enter username" value="<?php echo $show['nama']?>">
						  </div>
						  <div class="form-group">
						    <label for="exampleInputPassword1">PASSWORD</label>
						    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" value="<?php echo $show['password']?>">
						  </div>
						  <button type="submit" name="update" class="btn btn-primary" style="margin-left:220px;">update</button>
						</form>
					  </div>
					</div>
				</div>
				<div class="col-md-4">
					
				</div>

			</div><!-- penutup slide -->

			

	</div><!-- penutup backround -->



</div>
</body>
</html>