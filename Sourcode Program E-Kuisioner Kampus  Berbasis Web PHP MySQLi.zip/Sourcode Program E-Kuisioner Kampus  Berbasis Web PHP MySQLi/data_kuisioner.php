<!DOCTYPE html>
<html>
<head>
	<?php 
		include"body/head.php";
	 ?>
</head>
<body>
<div class="container">
	<div class="col-md-12" style="margin-top:50px;">
		<div class="col-md-12">
			<?php 
				include"body/heading.php";
			 ?>
		</div>

			

			<div class="col-md-12" style="margin-top:20px;">
				
				
				<div class="col-md-12">
					<div class="panel panel-default">
					  <div class="panel-body">
					   DATA KUISIONER<br><br>
					    <a href="master.php" class="btn btn-primary">BACK</a>
					  </div>

					  <div class="panel panel-default">
					  <div class="panel-body">
					  			 <table class="table table-striped">

					  	<?php

								include"koneksi.php";

								$no = 0;
										$sql = "select * from tbl_kuisioner order by id_kuisioner desc";
										$query = mysqli_query($login,$sql);
										while ($data = mysqli_fetch_assoc($query))
										{
									$no++;
						  ?>		 
								  <tr>
								  	<td>Nama</td>
								  	<td><?php echo $data['nama']?></td>
						     	  </tr>	
								  <tr>
								  	<td>JURUSAN</td>
								  	<td><?php echo $data['jurusan']?></td>
								  </tr>
								  <tr>
								  	<td>Prodi</td>	
								  	<td><?php echo $data['prodi']?></td>
								  </tr>	
								  <tr>
								  	<td>Laboratorium computer</td>
								  	<td><?php echo $data['nilai1'];?></td>
								  </tr>
								  <tr>	
								  	<td>Kecanggihan/keterbaruan laboratorium komputer </td>
								  	<td><?php echo $data['nilai2'];?></td>
								  </tr>
								  <tr>
								  	<td>RUANGAN</td>	
								  	<td><?php echo $data['nilai3'];?></td>
								  </tr>
								  <tr>
								  	<td>Fasilitas pendingin/penyejuk  ruangan</td>	
								  	<td><?php echo $data['nilai4'];?></td>\
								  </tr>
								  <tr>
								  	<td>Ruang perpustakaan</td>	
								  	<td><?php echo $data['nilai5'];?></td>
								  </tr>
								  <tr>
								  	<td>Koleksi perpustakaan</td>	
								  	<td><?php echo $data['nilai6'];?></td>
								  </tr>
								  <tr>
								  	<td>Fasilitas  Wifi Gratis/Hot Spot</td>	
								  	<td><?php echo $data['nilai7'];?></td>
								  </tr>
								  <tr>
								  	<td>Taman/ Hall/ Ruang public</td>	
								  	<td><?php echo $data['nilai8'];?></td>
								  </tr>
								  <tr>	
								  	<td>Area parkir</td>
								  	<td><?php echo $data['nilai9'];?></td>
								  </tr>	
								  <tr>
								  	<td>Kantin</td>
								  	<td><?php echo $data['nilai10'];?></td>
								  </tr>
								  <tr>
								  	<td>Fasilitas Olah raga</td>	
								  	<td><?php echo $data['niali11'];?></td>
								  </tr>
								  <tr>
								  	<td>Fasilitas Ekstra kurikuler</td>	
								  	<td><?php echo $data['nilai12'];?></td>
								  </tr>
								  <tr>
								  	<td>Fasilitas Ibadah</td>	
								  	<td><?php echo $data['nilai13'];?></td>
								  </tr>
								  <tr>
								  	<td>Kamar mandi/Toilet</td>	
								  	<td><?php echo $data['nilai14'];?></td>
								  </tr>	
								  <tr>
								  	<td><a style="float: right;" class="btn btn-primary" href="proses_kuisioner/proses_delete.php?hapus=<?php echo $data['id_kuisioner']?>">HAPUS</a></td>
								  </tr>
								  <?php

									}

					   ?>
								</table>

					  </div>
					</div>
				</div>	
				</div>

				

			</div><!-- penutup slide -->

			

	</div><!-- penutup backround -->



</div>
</body>
</html>