<title>Kuisioner STMIK NH JAMBI</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<script type="text/javascript" src="assets/js/jquery-2.0.2.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/icon.css">
	<link rel="stylesheet" type="text/css" href="master.css">
	<link rel="icon" type="text/css" href="img/1.jpg">